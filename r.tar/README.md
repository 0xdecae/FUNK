# FUNK

[Fuck You Not Knowing] What I'm Doing...
Pillaging scripts for post-exploitation shenanigans

Born within thee TuruT project, the wee-lad' was just a smol' config.sh. Disablin' firewalls, addin' users, plantin' backdoors n' shit.
Now the teeny thing has a chance to grow and prosper. May ye' help it in it's quest for bring forth creation, out of destruction.


