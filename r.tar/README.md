# FUNK

These are the collection of scripts formally known as FUNK. Basically they are a set of action items for a 'config.sh' bash script. The scripts implements various forms of post-exploitation pillaging on CentOS and Ubuntu Linux machines. 

Currently, the devastation encompasses:
	- Attempt to open firewall (U/C)
	- 	- Add sudo backup users
	- 	- Ensure sudo doesnt need password
	- 	- SUID bins
	- 	- Drop prism bins
	- 	- Establish systemd persistence
	- 	- Timestomp
	- 
For educational use only. Do not use on unauthorized systems. Use at your own risk.



